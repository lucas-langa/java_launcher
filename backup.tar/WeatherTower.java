public class WeatherTower extends Tower{
	
	public String 	getWeather( Coordinates coordinates ) {
		return ("SUN");
	}

	public void changeWeather( ) {
		
	}
                                                                                                                                                                                   
	/*
	** changeWeather
	*/
}